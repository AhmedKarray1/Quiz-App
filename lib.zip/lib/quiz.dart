import 'package:flutter/material.dart';
import 'package:flutter1_udemy/question.dart';
import 'answer.dart';
import 'question.dart';

class Quiz extends StatelessWidget {
  final questions;
  final question_index;
  final Function answerQs;
  Quiz(this.answerQs, this.question_index, this.questions);
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Question(questions[question_index]
            //on ajoute as string
            ['questionText'] as String),
        ...(questions[question_index]['answers'] as List<Map<String, Object>>)
            .map((answer) {
          return Answer(() => answerQs(answer['score']), answer["text"]);
        }).toList()
      ],
    );
  }
}
