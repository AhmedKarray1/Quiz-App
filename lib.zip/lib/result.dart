import 'package:flutter/material.dart';

class Result extends StatelessWidget {
  
var total_score;
final VoidCallback reset;
Result(this.total_score,this.reset);
String get resultPhrase{
  if (total_score<=8){
return("you're awesome and innocent !");}
else if(total_score<=12)
{return("pretty likeable");

}
else if(total_score>=16)
{return("you are strange");


}
else {
return ("you are so bad");

}
  }

 @override
  Widget build(BuildContext context) {
    return  Column(
      children: [
        Center(child:Text(resultPhrase,
        style: TextStyle(fontSize: 36,fontWeight:FontWeight.bold),
        textAlign: TextAlign.center,)),
        FloatingActionButton(onPressed:reset ,child: Text("reset"),)
      ],
    );
  }
}