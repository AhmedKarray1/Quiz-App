import 'package:flutter/material.dart';
import 'package:flutter1_udemy/quiz.dart';
import 'package:flutter1_udemy/result.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _MyAppState();
  }
}

class _MyAppState extends State<MyApp> {
  var question_index = 0;
  var total_score=0;
  

void reset()
{setState(() {question_index=0;
total_score=0;
  
});   



}
  
  void answerQs(int score) {
    setState(() {

      question_index += 2;
     
    });
    total_score+=score;

  
  }

  @override
  Widget build(BuildContext context) {
    final  List<Map<String, Object>> questions = [
    {
      'questionText': 'What\'s your favorite color?',
      'answers': [
        {'text': 'Black', 'score': 10},
        {'text': 'Red', 'score': 5},
        {'text': 'Green', 'score': 3},
        {'text': 'White', 'score': 1},
      ],
    },
    {
      'questionText': 'What\'s your favorite animal?',
      'answers': [
        {'text': 'Rabbit', 'score': 3},
        {'text': 'Snake', 'score': 11},
        {'text': 'Elephant', 'score': 5},
        {'text': 'Lion', 'score': 9},
      ],
    },
    {
      'questionText': 'Who\'s your favorite player?',
      'answers': [
        {'text': 'messi', 'score': 1},
        {'text': 'ronaldo', 'score': 1},
        {'text': 'neymar', 'score': 1},
        {'text': 'pato', 'score': 1},
      ],
    },
  ];
    return MaterialApp(
        home: Scaffold(
      appBar: AppBar(title: Text('My first app')),
      body: question_index<3 ? 
      Quiz(answerQs, question_index, questions)
      
      
      
      :Result(total_score,reset)
    ));
  }
}
